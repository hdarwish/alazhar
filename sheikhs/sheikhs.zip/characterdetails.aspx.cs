﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class sheikhs_characterdetails : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        //{
            Session["content_id"] = Request["id"];
            Session["content_type"] = "1";
            //Session["referred"] = "true";
            int id = Convert.ToInt16(Request.QueryString["id"]);
            HiddenID.Value = id.ToString();
            if (id > 0)
            { hits_count obj = new hits_count(); 
                obj.hit_count_save(id, 1); }
                
            
            //fillcheck_periods();
            fillchar_type();
            View();
           
        //}

    }
    private void fillchar_type()
    {
        char_types_DT obj = new char_types_DT();
        DataTable obj_db = char_types_DB.SelectAll();
        rad_char_type.DataSource = obj_db;
        //chk_char_type.DataTextField = "title_ar";
        //chk_char_type.DataValueField = "id";
        rad_char_type.DataBind();

    }
    private void fillcheck_periods()
    {
        periods_DT obj = new periods_DT();
        DataTable per_dt = periods_DB.SelectAll();
       // chk_periods.DataSource = per_dt;
       // chk_periods.DataBind();
        //chk_periods.DataValueField = "id";
        // chk_periods.DataTextField = "title";

    }
    public void View()
    {
        characters_DT obj = new characters_DT();
        characters_details_DT obj_dt = new characters_details_DT();
        obj = characters_DB.SelectByID(CDataConverter.ConvertToInt(HiddenID.Value));
        obj_dt = characters_details_DB.SelectBychar_ID(CDataConverter.ConvertToInt(HiddenID.Value), menus_update.get_current_lang());
        if (obj != null)
        {
            if (obj.form_status != 12)
                Response.Redirect("~/sheikhs/Default.aspx");
        }
        if (obj.char_type > 0)
        { rad_char_type.SelectedValue = obj.char_type.ToString(); }

        if (obj.char_type != null)
        {
            if (obj.char_type > 0)
            {
                string id = obj.char_type.ToString();
                rad_char_type.Items.FindByValue(id).Selected = true;
            }
            lbl_char_type.Text = rad_char_type.SelectedItem.Text;
        }
        else
        {
            trchartype.Visible = false;
        }


        //if (obj.period_id_multi != null && obj.period_id_multi != "")
        //{
        //    String[] temp = obj.period_id_multi.ToString().Split(',');
        //    if (temp.Length > 0)
        //    {
        //        for (int j = 0; j < temp.Length; j++)
        //        {
        //            for (int i = 0; i < chk_periods.Items.Count; i++)
        //            {

        //                if (temp[j] == chk_periods.Items[i].Value)
        //                {
        //                    if (j > 0)
        //                    {
        //                        chk_periods.Items[i].Selected = true;
        //                        lbl_chk_periods.Text += ", " + chk_periods.Items[i].Text;
        //                    }
        //                    else
        //                    {
        //                        chk_periods.Items[i].Selected = true;
        //                        lbl_chk_periods.Text += chk_periods.Items[i].Text;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
        Image lcImage = (Image)Page.Master.FindControl("leftUC11").FindControl("Image1");
        if (obj.image_name != "")
        {

            lcImage.ImageUrl = "../images/sheikhs/" + obj.image_name;
        }
        else lcImage.ImageUrl = "../img/azhar-char.gif";
        Label lclabel = (Label)Page.Master.FindControl("leftUC11").FindControl("content_txt");
        lclabel.Text = "الشخصية";
        txt_name.Text = obj_dt.name;
        if (obj_dt.activities != null && obj_dt.activities != "")
            txt_activities.Text = obj_dt.activities;
        else
        { tractivities.Visible = tracti.Visible = false; }

        if (obj_dt.birth_details != null && obj_dt.birth_details != "")
            txt_birth_details.Text = obj_dt.birth_details;
        else
        {
            trbdetails.Visible = trnash2a.Visible = false;
        }

        if (obj_dt.char_details != null && obj_dt.char_details != "")
            txt_char_details.Text = obj_dt.char_details;
        else
        {
            trdetails.Visible = trnabtha.Visible = false;
        }

        if ((obj_dt.birth_date == null || obj_dt.birth_date == "") &&
         (obj_dt.hbirth_date == null || obj_dt.hbirth_date == ""))
        { trhbirthdate.Visible = false; }
        else
        {
            txt_birth_date.Text = obj_dt.birth_date;
            txt_hbirth_date.Text = obj_dt.hbirth_date;
        }

        if ((obj_dt.death_date == null || obj_dt.death_date == "") &&
         (obj_dt.hdeath_date == null || obj_dt.hdeath_date == ""))
        { trhdeathdate.Visible = false; }
        else
        {
            txt_death_date.Text = obj_dt.death_date;
            txt_hdeath_date.Text = obj_dt.hdeath_date;
        }
        if (obj_dt.other_names != null && obj_dt.other_names != "")
            txt_other_name.Text = obj_dt.other_names;
        else
        {
            trothername.Visible = trshohra.Visible = false;
        }
        if (obj_dt.scientific_life != null && obj_dt.scientific_life != "")
            txt_scientific_life.Text = obj_dt.scientific_life;
        else
        {
            trscientific.Visible = trsci.Visible = false;
        }
        if (obj_dt.working_life != null && obj_dt.working_life != "")
            txt_working_life.Text = obj_dt.working_life;
        else
        { trworklife.Visible = trworkin.Visible = false; }

        if (obj_dt.written_about != null && obj_dt.written_about != "")
            txt_written_about.Text = obj_dt.written_about;
        else
        {
            trwhtwritten.Visible = trsaid.Visible = false;
        }

        if (obj_dt.titles != null && obj_dt.titles != "")
            txt_titles.Text = obj_dt.titles;
        else
        {
            trtitles.Visible = tral2ab.Visible = false;
        }

        if (obj_dt.notes != null && obj_dt.notes != "")
            txt_notes.Text = obj_dt.notes;
        else
        {
            trnotes.Visible = trn.Visible = false;
        }
      

        achievements_details_DT achvd_dt = achievements_details_DB.SelectBy_CharID(CDataConverter.ConvertToInt(HiddenID.Value), menus_update.get_current_lang());

        if (achvd_dt != null)
        { txt_achiev.Text = achvd_dt.details; }
        else
        {
            trachieve.Visible = trach.Visible = false;
        }

        DataTable wesams = awsema_details_DB.select_bychar_id(CDataConverter.ConvertToInt(HiddenID.Value));
        if (wesams.Rows.Count > 0)
        {
            txt_awesma.Text = wesams.Rows[0]["details"].ToString();
        }
        else
        {
            trawsma.Visible = trmalm.Visible = false;
        }

        //SqlParameter[] newSqlParams = new SqlParameter[] { new SqlParameter("@char_id", CDataConverter.ConvertToInt(HiddenID.Value)) };
        //DataTable dt1 = DatabaseFunctions.SelectData(newSqlParams, "char_molafat_select_bycontentid0");
        //DataTable dt2 = DatabaseFunctions.SelectData(newSqlParams, "char_molafat_select_bycontentid");
        ////ShowAlertMessage(content_id.Value+","+dt1.Rows.Count.ToString()+","+dt2.Rows.Count.ToString());//+id.ToString()
        //if (dt1.Rows.Count > 0 || dt2.Rows.Count > 0) //|| dt2.Rows.Count > 0
        //{

        //    dt2.Merge(dt1);
        //    GridView1.DataSource = dt2;
        //    GridView1.DataBind();

        //}

        //DataTable dt = content_references_DB.SelectByContentID_type(CDataConverter.ConvertToInt("1"), CDataConverter.ConvertToInt(HiddenID.Value));
        //GridView2.DataSource = dt;
        //GridView2.DataBind();
     
       

    }
    //protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        int type = (int)Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "moalaf_type"));
    //        Label lab = (Label)e.Row.FindControl("moalaf_type");
    //        if (type == 1)
    //        {
    //            lab.Text = "مؤلف";
    //        }
    //        if (type == 2)
    //        { lab.Text = "مؤلف عنه"; }


    //    }
    //}
    //protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        int type = (int)Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "content_type2"));
    //        Label lab = (Label)e.Row.FindControl("type");

    //        if (type == 6)
    //        {
    //            lab.Text = "تسجيل تليفزيوني";
    //        }
    //        if (type == 7)
    //        {
    //            lab.Text = "تسجيل إذاعي";
    //        }

    //        if (type == 8)
    //        {
    //            lab.Text = "الوثائق";
    //        }
    //        if (type == 9)
    //        { lab.Text = " المقالات"; }
    //        if (type == 10)
    //        { lab.Text = " الكتب"; }
    //        if (type == 11)
    //        { lab.Text = "الصور"; }
    //        if (type == 12)
    //        { lab.Text = " المخطوطات"; }
    //        if (type == 13)
    //        { lab.Text = " أطروحة"; }
    //        if (type == 14)
    //        { lab.Text = " بحث في مؤتمر"; }
    //        if (type == 15)
    //        { lab.Text = "موقع إلكترونى"; }
    //        if (type == 16)
    //        { lab.Text = "المصطلحات"; }
    //    }
    //}
}
